console.log("page loaded...");

function over(element){
    document.getElementById("video").play();
}

function out(element){
    document.getElementById("video").pause();
}