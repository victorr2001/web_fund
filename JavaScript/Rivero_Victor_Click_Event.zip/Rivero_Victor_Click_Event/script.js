function logout(element){
    element.innerText = "Logout";
}

function take(element){
    element.remove();
}
